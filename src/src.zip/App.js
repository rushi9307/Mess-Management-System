//import logo from './logo.svg';
import './App.css';
import OwnerComponent from "./Components/OwnerComponent";
import AddOwner from "./Components/AddOwner";
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom'
import UpdateOwner from './Components/UpdateOwner';


function App() {
  return (
    <div className="container">
          <Router>
              <div className="col-md-6">
                  <h1 className="text-center" >E-Rasoi</h1>
                  <Switch>
                      <Route path="/" exact component={OwnerComponent} />
                      <Route path="/owners" component={OwnerComponent} />
                      <Route path="/add-owner" component={AddOwner} />
                      <Route path="/update-owner" component={UpdateOwner} />
                  </Switch>
              </div>
          </Router>
      </div>
  );
}

export default App;
